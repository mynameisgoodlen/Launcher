# No custom shrinker rules are required for this Java-only launcher.
