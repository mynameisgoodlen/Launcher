package org.pococ3.blockstart;

/** Pure launch gating logic, isolated so its duplicate-tap behavior can be unit-tested. */
public final class LaunchPolicy {
    private LaunchPolicy() { }

    public static boolean canLaunch(boolean installed, boolean hasLaunchIntent, boolean launchPending) {
        return installed && hasLaunchIntent && !launchPending;
    }
}
