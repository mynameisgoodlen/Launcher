package org.pococ3.blockstart;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String MINECRAFT_PACKAGE = "com.mojang.minecraftpe";
    private static final int BG = Color.rgb(11, 17, 16);
    private static final int PANEL = Color.rgb(23, 34, 30);
    private static final int PANEL_BORDER = Color.rgb(47, 65, 55);
    private static final int TEXT = Color.rgb(238, 244, 237);
    private static final int MUTED = Color.rgb(164, 180, 169);
    private static final int ACCENT = Color.rgb(183, 243, 107);
    private static final int RED = Color.rgb(255, 135, 125);

    private TextView statusValue;
    private TextView versionValue;
    private TextView packageValue;
    private TextView splitValue;
    private TextView deviceValue;
    private TextView messageValue;
    private Button launchButton;
    private Button playStoreButton;

    private PackageInfo minecraftInfo;
    private Intent minecraftLaunchIntent;
    private boolean minecraftInstalled;
    private boolean launchPending;
    private String lastError = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        setContentView(buildScreen());
        refreshMinecraftStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (statusValue != null) {
            launchPending = false;
            refreshMinecraftStatus();
        }
    }

    private View buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(28), dp(22), dp(30));
        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView brand = text("BLOCKSTART", 14, ACCENT, true);
        brand.setLetterSpacing(0.18f);
        content.addView(brand, matchWrap());

        TextView heading = text("Minecraft, one tap away.", 27, TEXT, true);
        LinearLayout.LayoutParams headingParams = matchWrap();
        headingParams.topMargin = dp(13);
        content.addView(heading, headingParams);

        TextView subtitle = text("A lightweight launcher for the official game already installed on this device.", 14, MUTED, false);
        LinearLayout.LayoutParams subtitleParams = matchWrap();
        subtitleParams.topMargin = dp(8);
        subtitleParams.bottomMargin = dp(24);
        content.addView(subtitle, subtitleParams);

        LinearLayout gamePanel = panel();
        content.addView(gamePanel, matchWrapWithTop(0));
        gamePanel.addView(sectionLabel("MINECRAFT STATUS"), matchWrap());
        statusValue = text("Checking installation…", 20, TEXT, true);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.topMargin = dp(10);
        gamePanel.addView(statusValue, statusParams);
        versionValue = infoRow(gamePanel, "Version", "Checking…");
        packageValue = infoRow(gamePanel, "Package", MINECRAFT_PACKAGE);
        splitValue = infoRow(gamePanel, "Installed splits", "—");

        LinearLayout devicePanel = panel();
        LinearLayout.LayoutParams devicePanelParams = matchWrap();
        devicePanelParams.topMargin = dp(14);
        content.addView(devicePanel, devicePanelParams);
        devicePanel.addView(sectionLabel("DEVICE RUNTIME"), matchWrap());
        deviceValue = text(getRuntimeDescription(), 14, TEXT, false);
        LinearLayout.LayoutParams deviceParams = matchWrap();
        deviceParams.topMargin = dp(10);
        devicePanel.addView(deviceValue, deviceParams);

        launchButton = button("LAUNCH MINECRAFT", ACCENT, BG);
        LinearLayout.LayoutParams launchParams = matchWrap();
        launchParams.topMargin = dp(20);
        content.addView(launchButton, launchParams);
        launchButton.setOnClickListener(v -> launchMinecraft());

        playStoreButton = button("OPEN OFFICIAL PLAY STORE LISTING", PANEL, TEXT);
        LinearLayout.LayoutParams storeParams = matchWrap();
        storeParams.topMargin = dp(10);
        content.addView(playStoreButton, storeParams);
        playStoreButton.setOnClickListener(v -> openPlayStoreListing());
        playStoreButton.setVisibility(View.GONE);

        messageValue = text("", 13, MUTED, false);
        LinearLayout.LayoutParams messageParams = matchWrap();
        messageParams.topMargin = dp(12);
        content.addView(messageValue, messageParams);

        Button refreshButton = button("RESCAN", PANEL, TEXT);
        LinearLayout.LayoutParams refreshParams = matchWrap();
        refreshParams.topMargin = dp(12);
        content.addView(refreshButton, refreshParams);
        refreshButton.setOnClickListener(v -> {
            launchPending = false;
            refreshMinecraftStatus();
        });

        Button settingsButton = button("SETTINGS & DIAGNOSTICS", PANEL, MUTED);
        LinearLayout.LayoutParams settingsParams = matchWrap();
        settingsParams.topMargin = dp(10);
        content.addView(settingsButton, settingsParams);
        settingsButton.setOnClickListener(v -> showDiagnostics());

        TextView footer = text("BlockStart does not modify Minecraft files or worlds.", 12, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerParams = matchWrap();
        footerParams.topMargin = dp(24);
        content.addView(footer, footerParams);
        return scroll;
    }

    private void refreshMinecraftStatus() {
        PackageManager pm = getPackageManager();
        try {
            PackageInfo info = getMinecraftPackageInfo(pm);
            minecraftInfo = info;
            minecraftInstalled = true;
            minecraftLaunchIntent = pm.getLaunchIntentForPackage(MINECRAFT_PACKAGE);
            lastError = "";

            statusValue.setText(minecraftLaunchIntent == null
                    ? "Installed · no launch intent"
                    : "Installed · ready to launch");
            statusValue.setTextColor(minecraftLaunchIntent == null ? RED : ACCENT);

            String versionName = info.versionName;
            if (versionName == null || versionName.trim().isEmpty()) {
                versionName = "Not reported by Android";
            }
            long versionCode = Build.VERSION.SDK_INT >= 28
                    ? info.getLongVersionCode()
                    : info.versionCode;
            versionValue.setText(versionName + "  (code " + versionCode + ")");

            ApplicationInfo appInfo = info.applicationInfo;
            int splitCount = appInfo == null || appInfo.splitNames == null
                    ? 0 : appInfo.splitNames.length;
            if (splitCount == 0 && appInfo != null && appInfo.splitSourceDirs != null) {
                splitCount = appInfo.splitSourceDirs.length;
            }
            splitValue.setText(splitCount + (splitCount == 1 ? " split" : " splits")
                    + " · metadata only");
            packageValue.setText(MINECRAFT_PACKAGE);

            if (minecraftLaunchIntent == null) {
                messageValue.setText("Android reports the package as installed, but did not return a front-door launch intent.");
                messageValue.setTextColor(RED);
            } else {
                messageValue.setText("Ready. Minecraft will open as its own Android application.");
                messageValue.setTextColor(MUTED);
            }
            playStoreButton.setVisibility(View.GONE);
        } catch (PackageManager.NameNotFoundException e) {
            minecraftInstalled = false;
            minecraftInfo = null;
            minecraftLaunchIntent = null;
            lastError = e.getClass().getSimpleName();
            statusValue.setText("Minecraft is not installed");
            statusValue.setTextColor(RED);
            versionValue.setText("—");
            splitValue.setText("—");
            packageValue.setText(MINECRAFT_PACKAGE);
            messageValue.setText("Install the official game from Google Play, then tap RESCAN.");
            messageValue.setTextColor(MUTED);
            playStoreButton.setVisibility(View.VISIBLE);
        } catch (SecurityException e) {
            setInspectionError("Android denied access to Minecraft package information.", e);
        } catch (RuntimeException e) {
            setInspectionError("Could not inspect the Minecraft installation.", e);
        }
        deviceValue.setText(getRuntimeDescription());
        updateLaunchButton();
    }

    private PackageInfo getMinecraftPackageInfo(PackageManager pm)
            throws PackageManager.NameNotFoundException {
        if (Build.VERSION.SDK_INT >= 33) {
            return pm.getPackageInfo(MINECRAFT_PACKAGE, PackageManager.PackageInfoFlags.of(0));
        }
        return pm.getPackageInfo(MINECRAFT_PACKAGE, 0);
    }

    private void setInspectionError(String message, RuntimeException error) {
        minecraftInstalled = false;
        minecraftInfo = null;
        minecraftLaunchIntent = null;
        lastError = error.getClass().getSimpleName();
        statusValue.setText("Unable to inspect installation");
        statusValue.setTextColor(RED);
        versionValue.setText("—");
        splitValue.setText("—");
        messageValue.setText(message + " Details: " + lastError);
        messageValue.setTextColor(RED);
        playStoreButton.setVisibility(View.GONE);
    }

    private void launchMinecraft() {
        if (!LaunchPolicy.canLaunch(minecraftInstalled, minecraftLaunchIntent != null, launchPending)) {
            refreshMinecraftStatus();
            if (minecraftInstalled && minecraftLaunchIntent == null) {
                messageValue.setText("Minecraft is installed, but Android did not provide a launch intent.");
                messageValue.setTextColor(RED);
            }
            return;
        }

        launchPending = true;
        messageValue.setText("Sending launch request to Android…");
        messageValue.setTextColor(MUTED);
        updateLaunchButton();
        try {
            startActivity(minecraftLaunchIntent);
        } catch (ActivityNotFoundException e) {
            showLaunchFailure("Android could not resolve Minecraft's launch activity.", e);
        } catch (SecurityException e) {
            showLaunchFailure("Android blocked the launch request.", e);
        } catch (RuntimeException e) {
            showLaunchFailure("Minecraft could not be started.", e);
        }
    }

    private void showLaunchFailure(String message, RuntimeException error) {
        launchPending = false;
        lastError = error.getClass().getSimpleName();
        messageValue.setText(message + " Details: " + lastError);
        messageValue.setTextColor(RED);
        updateLaunchButton();
    }

    private void updateLaunchButton() {
        if (launchButton == null) return;
        boolean canLaunch = LaunchPolicy.canLaunch(minecraftInstalled,
                minecraftLaunchIntent != null, launchPending);
        launchButton.setEnabled(canLaunch);
        launchButton.setAlpha(canLaunch ? 1.0f : 0.48f);
        launchButton.setText(launchPending ? "STARTING MINECRAFT…"
                : (canLaunch ? "LAUNCH MINECRAFT" : "MINECRAFT UNAVAILABLE"));
    }

    private void openPlayStoreListing() {
        Uri marketUri = Uri.parse("market://details?id=" + MINECRAFT_PACKAGE);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, marketUri));
        } catch (ActivityNotFoundException | SecurityException firstFailure) {
            Uri webUri = Uri.parse("https://play.google.com/store/apps/details?id=" + MINECRAFT_PACKAGE);
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, webUri));
            } catch (ActivityNotFoundException | SecurityException secondFailure) {
                lastError = secondFailure.getClass().getSimpleName();
                messageValue.setText("No app could open the Play Store listing. Details: " + lastError);
                messageValue.setTextColor(RED);
            }
        }
    }

    private void showDiagnostics() {
        String version = minecraftInfo == null ? "Not installed / unavailable"
                : String.valueOf(minecraftInfo.versionName) + " (code "
                + (Build.VERSION.SDK_INT >= 28 ? minecraftInfo.getLongVersionCode() : minecraftInfo.versionCode) + ")";
        String diagnostic = "Launcher: " + getPackageName()
                + "\nTarget package: " + MINECRAFT_PACKAGE
                + "\nMinecraft: " + (minecraftInstalled ? "installed" : "not detected")
                + "\nGame version: " + version
                + "\nAndroid: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"
                + "\nSupported ABIs: " + Arrays.toString(Build.SUPPORTED_ABIS)
                + "\nCurrent process: " + (Process.is64Bit() ? "64-bit" : "32-bit")
                + "\nLauncher native libraries: none (Java only)"
                + "\nLast error: " + (lastError.isEmpty() ? "none" : lastError)
                + "\n\nMinecraft APKs and worlds are not read, extracted, copied, or modified.";
        new AlertDialog.Builder(this)
                .setTitle("Settings & diagnostics")
                .setMessage(diagnostic)
                .setPositiveButton("CLOSE", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private String getRuntimeDescription() {
        return "Android " + Build.VERSION.RELEASE + " · API " + Build.VERSION.SDK_INT
                + "\nProcess: " + (Process.is64Bit() ? "64-bit" : "32-bit")
                + "\nABIs: " + Arrays.toString(Build.SUPPORTED_ABIS);
    }

    private LinearLayout panel() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(17), dp(17), dp(17), dp(17));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(PANEL);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), PANEL_BORDER);
        layout.setBackground(bg);
        return layout;
    }

    private TextView infoRow(LinearLayout parent, String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rowParams = matchWrap();
        rowParams.topMargin = dp(13);
        parent.addView(row, rowParams);
        row.addView(text(label.toUpperCase(Locale.ROOT), 10, MUTED, true), matchWrap());
        TextView valueView = text(value, 14, TEXT, false);
        LinearLayout.LayoutParams valueParams = matchWrap();
        valueParams.topMargin = dp(3);
        row.addView(valueView, valueParams);
        return valueView;
    }

    private TextView sectionLabel(String value) {
        TextView label = text(value, 10, MUTED, true);
        label.setLetterSpacing(0.12f);
        return label;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setIncludeFontPadding(true);
        return view;
    }

    private Button button(String label, int backgroundColor, int textColor) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(13);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(textColor);
        button.setAllCaps(false);
        button.setMinHeight(dp(52));
        button.setPadding(dp(12), dp(9), dp(12), dp(9));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(backgroundColor);
        bg.setCornerRadius(dp(14));
        if (backgroundColor == PANEL) bg.setStroke(dp(1), PANEL_BORDER);
        button.setBackground(bg);
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWrapWithTop(int top) {
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = top;
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
