package org.pococ3.blockstart;

import org.junit.Test;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class LaunchPolicyTest {
    @Test public void installedPackageWithLaunchIntentCanLaunch() {
        assertTrue(LaunchPolicy.canLaunch(true, true, false));
    }

    @Test public void missingPackageCannotLaunch() {
        assertFalse(LaunchPolicy.canLaunch(false, false, false));
    }

    @Test public void installedPackageWithoutFrontDoorIntentCannotLaunch() {
        assertFalse(LaunchPolicy.canLaunch(true, false, false));
    }

    @Test public void pendingLaunchBlocksRepeatedTap() {
        assertFalse(LaunchPolicy.canLaunch(true, true, true));
    }
}
